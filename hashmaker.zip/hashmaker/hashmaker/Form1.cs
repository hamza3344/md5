﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace hashmaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string data = "Hello, World!"; // Data to be hashed
            string md5 = GetHash(data, new MD5CryptoServiceProvider());
            MessageBox.Show("MD5: " + md5);
            string sha1 = GetHash(data, new SHA1CryptoServiceProvider());
            MessageBox.Show("SHA1: " + sha1);
            string sha256 = GetHash(data, new SHA256CryptoServiceProvider());
            MessageBox.Show("Sha256: " + sha256);

        }
        static string GetHash(string input,HashAlgorithm hashAlgorithm)
        {
            byte[] data=hashAlgorithm.ComputeHash(Encoding.UTF8.GetBytes(input));
            StringBuilder sb=new StringBuilder();
            foreach(byte b in data)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

    }
}
